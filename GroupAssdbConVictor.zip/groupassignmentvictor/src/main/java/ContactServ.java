

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ContactServ
 */
@WebServlet("/ContactServ")
public class ContactServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql:///maxtekbankdb","root","Victor@Gonzalez_03?");
			String name=request.getParameter("name");
			String email=request.getParameter("email");
			String textfield=request.getParameter("textfield");

		
			PreparedStatement ps = con.prepareStatement("INSERT INTO maxtekbankdb.contacts (name,email,textfield) VALUES (?,?,?)");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,textfield);
			
			ps.executeUpdate();
			  
	        // Close all the connections
	        ps.close();
	        con.close();
			
	        // Get a writer pointer 
            // to display the successful result
            PrintWriter out = response.getWriter();
            out.println("<html><body><b>Successfully Inserted"
                        + "</b></body></html>");
            
			} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			};


			}

			}
